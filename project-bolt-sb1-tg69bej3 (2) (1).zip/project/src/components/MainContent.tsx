import { Heart, MoreHorizontal, Search, Filter, ArrowLeft } from 'lucide-react';
import { useState } from 'react';
import VehicleModal from './VehicleModal';

export default function MainContent() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedVehicle, setSelectedVehicle] = useState<any>(null);

  const vehicles = [
    // Electric Vehicles
    {
      name: "Tesla Model S",
      category: "Electric Vehicles",
      price: "$74,990",
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14f1256?w=300&h=200&fit=crop"
    },
    {
      name: "Tesla Model 3",
      category: "Electric Vehicles",
      price: "$38,990",
      image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=300&h=200&fit=crop"
    },
    {
      name: "Tesla Model X",
      category: "Electric Vehicles",
      price: "$79,990",
      image: "https://images.unsplash.com/photo-1566152446568-98b8d5b71b8c?w=300&h=200&fit=crop"
    },
    {
      name: "Tesla Model Y",
      category: "Electric Vehicles",
      price: "$43,990",
      image: "https://images.unsplash.com/photo-1619317554478-c3a64d6c0c7b?w=300&h=200&fit=crop"
    },
    {
      name: "Rivian R1T",
      category: "Electric Vehicles",
      price: "$73,000",
      image: "https://images.unsplash.com/photo-1655610982559-6cd2ab428e0f?w=300&h=200&fit=crop"
    },
    {
      name: "Rivian R1S",
      category: "Electric Vehicles",
      price: "$78,000",
      image: "https://images.unsplash.com/photo-1655610982559-6cd2ab428e0f?w=300&h=200&fit=crop"
    },
    {
      name: "BMW i4",
      category: "Electric Vehicles",
      price: "$51,400",
      image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=300&h=200&fit=crop"
    },
    {
      name: "BMW iX",
      category: "Electric Vehicles",
      price: "$84,100",
      image: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=300&h=200&fit=crop"
    },
    {
      name: "Porsche Taycan",
      category: "Electric Vehicles",
      price: "$88,150",
      image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=300&h=200&fit=crop"
    },
    {
      name: "Lucid Air",
      category: "Electric Vehicles",
      price: "$87,400",
      image: "https://images.unsplash.com/photo-1619317554478-c3a64d6c0c7b?w=300&h=200&fit=crop"
    },
    {
      name: "Polestar 2",
      category: "Electric Vehicles",
      price: "$49,800",
      image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=300&h=200&fit=crop"
    },
    {
      name: "Audi e-tron GT",
      category: "Electric Vehicles",
      price: "$102,400",
      image: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=300&h=200&fit=crop"
    },
    
    // Luxury Cars
    {
      name: "Mercedes-Benz S-Class",
      category: "Luxury Cars",
      price: "$114,500",
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=300&h=200&fit=crop"
    },
    {
      name: "BMW 7 Series",
      category: "Luxury Cars",
      price: "$93,300",
      image: "https://images.unsplash.com/photo-1556189250-72ba954cfc2b?w=300&h=200&fit=crop"
    },
    {
      name: "Audi A8",
      category: "Luxury Cars",
      price: "$86,500",
      image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=300&h=200&fit=crop"
    },
    {
      name: "Bentley Flying Spur",
      category: "Luxury Cars",
      price: "$215,000",
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=300&h=200&fit=crop"
    },
    {
      name: "Rolls-Royce Ghost",
      category: "Luxury Cars",
      price: "$343,000",
      image: "https://images.unsplash.com/photo-1556189250-72ba954cfc2b?w=300&h=200&fit=crop"
    },
    {
      name: "Lexus LS",
      category: "Luxury Cars",
      price: "$76,000",
      image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=300&h=200&fit=crop"
    },
    {
      name: "Genesis G90",
      category: "Luxury Cars",
      price: "$74,950",
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=300&h=200&fit=crop"
    },
    
    // Sports Cars
    {
      name: "Porsche 911",
      category: "Sports Cars",
      price: "$106,100",
      image: "https://images.unsplash.com/photo-1494905998402-395d579af36f?w=300&h=200&fit=crop"
    },
    {
      name: "Chevrolet Corvette C8",
      category: "Sports Cars",
      price: "$64,500",
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=300&h=200&fit=crop"
    },
    {
      name: "BMW M4",
      category: "Sports Cars",
      price: "$74,900",
      image: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=300&h=200&fit=crop"
    },
    {
      name: "Mercedes-AMG GT",
      category: "Sports Cars",
      price: "$118,600",
      image: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=300&h=200&fit=crop"
    },
    {
      name: "Audi R8",
      category: "Sports Cars",
      price: "$158,600",
      image: "https://images.unsplash.com/photo-1494905998402-395d579af36f?w=300&h=200&fit=crop"
    },
    {
      name: "McLaren 720S",
      category: "Sports Cars",
      price: "$299,000",
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=300&h=200&fit=crop"
    },
    {
      name: "Nissan GT-R",
      category: "Sports Cars",
      price: "$113,540",
      image: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=300&h=200&fit=crop"
    },
    {
      name: "Lotus Emira",
      category: "Sports Cars",
      price: "$93,900",
      image: "https://images.unsplash.com/photo-1494905998402-395d579af36f?w=300&h=200&fit=crop"
    },
    
    // SUVs
    {
      name: "Toyota Land Cruiser",
      category: "SUVs",
      price: "$89,160",
      image: "https://images.unsplash.com/photo-1533473359668-999ef5c49e09?w=300&h=200&fit=crop"
    },
    {
      name: "Range Rover",
      category: "SUVs",
      price: "$104,500",
      image: "https://images.unsplash.com/photo-1533473359668-999ef5c49e09?w=300&h=200&fit=crop"
    },
    {
      name: "BMW X7",
      category: "SUVs",
      price: "$77,850",
      image: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=300&h=200&fit=crop"
    },
    {
      name: "Mercedes-Benz GLS",
      category: "SUVs",
      price: "$81,800",
      image: "https://images.unsplash.com/photo-1549275301-c9d60c273972?w=300&h=200&fit=crop"
    },
    {
      name: "Cadillac Escalade",
      category: "SUVs",
      price: "$79,795",
      image: "https://images.unsplash.com/photo-1549275301-c9d60c273972?w=300&h=200&fit=crop"
    },
    {
      name: "Jeep Grand Wagoneer",
      category: "SUVs",
      price: "$88,640",
      image: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=300&h=200&fit=crop"
    },
    {
      name: "Lamborghini Urus",
      category: "SUVs",
      price: "$229,495",
      image: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=300&h=200&fit=crop"
    },
    {
      name: "Porsche Cayenne",
      category: "SUVs",
      price: "$72,200",
      image: "https://images.unsplash.com/photo-1549275301-c9d60c273972?w=300&h=200&fit=crop"
    },
    {
      name: "Aston Martin DBX",
      category: "SUVs",
      price: "$176,900",
      image: "https://images.unsplash.com/photo-1533473359668-999ef5c49e09?w=300&h=200&fit=crop"
    },
    {
      name: "Maserati Levante",
      category: "SUVs",
      price: "$79,400",
      image: "https://images.unsplash.com/photo-1549275301-c9d60c273972?w=300&h=200&fit=crop"
    },
    
    // Pickup Trucks
    {
      name: "Ford F-150",
      category: "Pickup Trucks",
      price: "$33,695",
      image: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=300&h=200&fit=crop"
    },
    {
      name: "RAM 1500",
      category: "Pickup Trucks",
      price: "$37,410",
      image: "https://images.unsplash.com/photo-1609630875171-b1321377ee65?w=300&h=200&fit=crop"
    },
    {
      name: "Chevrolet Silverado",
      category: "Pickup Trucks",
      price: "$35,600",
      image: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=300&h=200&fit=crop"
    },
    {
      name: "GMC Sierra",
      category: "Pickup Trucks",
      price: "$36,400",
      image: "https://images.unsplash.com/photo-1609630875171-b1321377ee65?w=300&h=200&fit=crop"
    },
    {
      name: "Toyota Tundra",
      category: "Pickup Trucks",
      price: "$36,965",
      image: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=300&h=200&fit=crop"
    },
    {
      name: "Nissan Titan",
      category: "Pickup Trucks",
      price: "$39,700",
      image: "https://images.unsplash.com/photo-1609630875171-b1321377ee65?w=300&h=200&fit=crop"
    },
    {
      name: "Honda Ridgeline",
      category: "Pickup Trucks",
      price: "$38,800",
      image: "https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=300&h=200&fit=crop"
    },
    
    // Sedans
    {
      name: "Honda Accord",
      category: "Sedans",
      price: "$26,520",
      image: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=300&h=200&fit=crop"
    },
    {
      name: "Toyota Camry",
      category: "Sedans",
      price: "$25,945",
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=300&h=200&fit=crop"
    },
    {
      name: "Hyundai Sonata",
      category: "Sedans",
      price: "$24,950",
      image: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=300&h=200&fit=crop"
    },
    {
      name: "Kia K5",
      category: "Sedans",
      price: "$25,090",
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=300&h=200&fit=crop"
    },
    {
      name: "Mazda6",
      category: "Sedans",
      price: "$24,475",
      image: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=300&h=200&fit=crop"
    },
    {
      name: "Nissan Altima",
      category: "Sedans",
      price: "$24,900",
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=300&h=200&fit=crop"
    },
    {
      name: "Volkswagen Passat",
      category: "Sedans",
      price: "$27,575",
      image: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=300&h=200&fit=crop"
    },
    {
      name: "Subaru Legacy",
      category: "Sedans",
      price: "$23,495",
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=300&h=200&fit=crop"
    }
  ];

  const categories = ['all', 'Electric Vehicles', 'Luxury Cars', 'Sports Cars', 'SUVs', 'Pickup Trucks', 'Sedans'];

  const filteredVehicles = vehicles.filter(vehicle => {
    const matchesSearch = vehicle.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || vehicle.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleBack = () => {
    setSelectedVehicle(null);
    setSearchQuery('');
    setSelectedCategory('all');
  };

  return (
    <div className="flex-1 bg-gradient-to-b from-blue-900 to-black overflow-auto h-screen pb-20">
      <div className="p-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button 
              onClick={handleBack}
              className="text-gray-400 hover:text-white transition flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg"
            >
              <ArrowLeft size={20} />
              <span>Back</span>
            </button>
            <h2 className="text-2xl font-bold text-white">Search Vehicles</h2>
          </div>
          <div className="flex items-center space-x-4">
            <button className="text-gray-400 hover:text-white transition">
              <Heart size={20} />
            </button>
            <button className="text-gray-400 hover:text-white transition">
              <MoreHorizontal size={20} />
            </button>
          </div>
        </div>

        {/* Search and Filter Section */}
        <div className="mb-8 space-y-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search vehicles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-lg py-2 pl-10 pr-4 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-white/10 border border-white/20 rounded-lg py-2 pl-10 pr-8 text-white appearance-none cursor-pointer focus:outline-none focus:border-blue-500"
              >
                {categories.map(category => (
                  <option key={category} value={category} className="bg-gray-900">
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVehicles.map((vehicle, index) => (
            <div 
              key={index}
              className="bg-white/5 rounded-lg overflow-hidden hover:bg-white/10 transition cursor-pointer group"
              onClick={() => setSelectedVehicle(vehicle)}
            >
              <div className="relative aspect-video">
                <img 
                  src={vehicle.image}
                  alt={vehicle.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold text-white mb-1">{vehicle.name}</h3>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-blue-400">{vehicle.category}</span>
                  <span className="text-sm font-medium text-white">{vehicle.price}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredVehicles.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400 text-lg">No vehicles found matching your search criteria</p>
          </div>
        )}
      </div>

      {selectedVehicle && (
        <VehicleModal 
          vehicle={selectedVehicle} 
          onClose={() => setSelectedVehicle(null)} 
        />
      )}
    </div>
  );
}