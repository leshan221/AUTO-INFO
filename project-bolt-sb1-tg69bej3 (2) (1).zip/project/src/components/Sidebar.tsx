import { Car, Search, Wrench, Fuel, Settings, Heart, Clock } from 'lucide-react';

export default function Sidebar() {
  return (
    <div className="w-64 bg-white h-full p-6 shadow-lg">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-blue-600 flex items-center gap-2">
          <Car size={28} />
          AutoInfo
        </h1>
        <nav className="mt-8 space-y-4">
          <a href="#" className="flex items-center space-x-4 text-gray-700 hover:text-blue-600 transition">
            <Search size={24} />
            <span>Search Vehicles</span>
          </a>
          <a href="#" className="flex items-center space-x-4 text-gray-700 hover:text-blue-600 transition">
            <Wrench size={24} />
            <span>Maintenance</span>
          </a>
          <a href="#" className="flex items-center space-x-4 text-gray-700 hover:text-blue-600 transition">
            <Fuel size={24} />
            <span>Fuel Economy</span>
          </a>
          <a href="#" className="flex items-center space-x-4 text-gray-700 hover:text-blue-600 transition">
            <Settings size={24} />
            <span>Compare Models</span>
          </a>
        </nav>
      </div>
      
      <div className="mt-8">
        <div className="flex flex-col space-y-4">
          <button className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition">
            <Heart className="text-red-500" size={24} />
            <span>Saved Vehicles</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition">
            <Clock className="text-gray-600" size={24} />
            <span>Recent Searches</span>
          </button>
        </div>
      </div>
    </div>
  );
}