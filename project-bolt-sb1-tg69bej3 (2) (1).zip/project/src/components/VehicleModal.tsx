import { X } from 'lucide-react';

interface VehicleModalProps {
  vehicle: {
    name: string;
    category: string;
    price: string;
    image: string;
  };
  onClose: () => void;
}

export default function VehicleModal({ vehicle, onClose }: VehicleModalProps) {
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-3xl w-full overflow-hidden relative animate-fade-in">
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700 z-10"
        >
          <X size={24} />
        </button>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="relative aspect-video md:aspect-auto">
            <img 
              src={vehicle.image}
              alt={vehicle.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{vehicle.name}</h2>
            <div className="flex items-center space-x-2 mb-4">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                {vehicle.category}
              </span>
              <span className="text-lg font-semibold text-gray-900">{vehicle.price}</span>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Key Features</h3>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li>Advanced Driver Assistance Systems</li>
                  <li>Premium Interior Materials</li>
                  <li>Latest Infotainment System</li>
                  <li>Enhanced Safety Features</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Performance</h3>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li>Powerful Engine Configuration</li>
                  <li>Smooth Transmission</li>
                  <li>Excellent Fuel Efficiency</li>
                  <li>Superior Handling</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Contact</h3>
                <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
                  Schedule a Test Drive
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}